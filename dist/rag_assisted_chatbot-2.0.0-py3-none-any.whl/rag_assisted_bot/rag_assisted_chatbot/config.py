GITHUB_USERNAME="vijaytakbhate2002"
GITHUB_PDF_FOLDER = "scrapped_data/github_pdfs"
METADATA_JSON_PATH = "scrapped_metadata/metadata.json"
VECTORDB_PATH = "vectordb_storage"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
TOP_K_MATCHES = 5
GPT_MODEL_NAME = 'gpt-5-mini'